$("a").click(function(){
  $(this).toggleClass("open");
  $("h1").addClass("fade");
});